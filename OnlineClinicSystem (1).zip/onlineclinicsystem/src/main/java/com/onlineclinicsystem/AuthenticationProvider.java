package com.onlineclinicsystem;

public enum AuthenticationProvider {

	LOCAL, GOOGLE
}
