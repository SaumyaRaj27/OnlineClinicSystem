package com.onlineclinicsystem.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.RestController;
//import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.onlineclinicsystem.AuthenticationRequest;
import com.onlineclinicsystem.AuthenticationResponse;
import com.onlineclinicsystem.CustomOAuth2UserService;
import com.onlineclinicsystem.JwtUtil;
import com.onlineclinicsystem.model.Doctor;
import com.onlineclinicsystem.model.Patient;
import com.onlineclinicsystem.service.CustomerUserDetailsService;
import com.onlineclinicsystem.service.DoctorService;
import com.onlineclinicsystem.service.PatientService;

@Controller
public class AppController {

	@Autowired
	private JwtUtil jwtTokenUtil;

	@Autowired
	private AuthenticationManager authenticationManager;

	@Autowired
	private PatientService patientService;

	@Autowired
	private CustomOAuth2UserService oAuthUserDetailsService;

	@Autowired
	private CustomerUserDetailsService userDetailsService;

	@Autowired
	private DoctorService doctorService;

	@RequestMapping("/")
	public String viewHomePage() {
		return "Home";
	}

	@RequestMapping("/doctorList")
	public String doctorsList(Model m) {
		List<Doctor> doctorList = doctorService.listAll();
		m.addAttribute("doctorList", doctorList);
		return "doctorList";
	}

	@RequestMapping("/patientLogin")
	public String login(Model m) {
		
		return "patientLogin";
	}

	@RequestMapping("/patientsignup")
	public String signup(Model m) {
		m.addAttribute("patient", new Patient());
		return "patient/Register";
	}

	@RequestMapping(value = "/patientsave", method = RequestMethod.POST)
	public String Register(@ModelAttribute("patient") Patient patient, Model model) {
		System.out.println(patient.getPatientId() + " " + patient.getEmail());
		patient.setRoles("ROLE_USER");
		BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
		String encodedPassword = encoder.encode(patient.getPassword());
		patient.setPassword(encodedPassword);
		patientService.save(patient);
		model.addAttribute("patient", patient);
		return "redirect:/";
	}

	@RequestMapping("/about")
	public String About() {
		return "About";
	}

	@RequestMapping("/logout")
	public String logout() {
		return "logout";
	}

	@RequestMapping("/patient")
	@ResponseBody
	public Principal patient(Principal principal) {
		return principal;
	}

	@RequestMapping(value = "/authenticate", method = RequestMethod.POST)
	public ResponseEntity<?> createAuthenticationToken(@RequestBody AuthenticationRequest authenticationRequest)
			throws Exception {

		try {
			authenticationManager.authenticate(
					new UsernamePasswordAuthenticationToken(authenticationRequest.getEmail(),
							authenticationRequest.getPassword()));
		}
		catch (BadCredentialsException e) {
			throw new Exception("Incorrect username or password", e);
		}

		final UserDetails userDetails = userDetailsService.loadUserByUsername(authenticationRequest.getEmail());
		
		final String jwt = jwtTokenUtil.generateToken(userDetails);

		return ResponseEntity.ok(new AuthenticationResponse(jwt));
	}
}
