package com.onlineclinicsystem.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.onlineclinicsystem.model.Appointments;

public interface AppointmentRepository extends JpaRepository<Appointments, Long> {


}
