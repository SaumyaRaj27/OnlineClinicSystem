package com.onlineclinicsystem.service;

import java.util.List;

//import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.onlineclinicsystem.model.Appointments;
import com.onlineclinicsystem.repository.AppointmentRepository;

@Service
public class AppointmentService {

	@Autowired
	private AppointmentRepository aptRepo;

	public List<Appointments> findAll() {
		return aptRepo.findAll();
	}

	public Appointments findById(long id) {
		return aptRepo.findById(id).get();
	}

	public void save(Appointments appointment) {
		aptRepo.save(appointment);
	}

	public void delete(Long userId) {
		aptRepo.deleteById(userId);
	}

}
