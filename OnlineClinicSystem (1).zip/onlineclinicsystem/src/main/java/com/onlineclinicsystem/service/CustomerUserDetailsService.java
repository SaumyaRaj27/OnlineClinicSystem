package com.onlineclinicsystem.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.onlineclinicsystem.CustomerUserDetails;
import com.onlineclinicsystem.model.Patient;
import com.onlineclinicsystem.repository.PatientRepository;

@Service
public class CustomerUserDetailsService implements UserDetailsService {

	@Autowired
	private PatientRepository patRepo;

	@Override
	public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
		Patient patient = patRepo.findByEmail(email);

		if (patient == null) {
			throw new UsernameNotFoundException("User Not Found");
		}
		
		return new CustomerUserDetails(patient);
	}

}
