package com.onlineclinicsystem.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.onlineclinicsystem.AuthenticationProvider;
import com.onlineclinicsystem.model.Patient;
import com.onlineclinicsystem.repository.PatientRepository;

@Service
public class PatientService {

	@Autowired
	private PatientRepository patRepo;

	public void save(Patient patient) {
		patRepo.save(patient);
	}

	public Patient get(Long userId) {
		return patRepo.findById(userId).get();
	}

	public void delete(Long userId) {
		patRepo.deleteById(userId);
	}

	public void createNewCustomerAfterOAuthLoginSuccess(String email, String name, AuthenticationProvider provider) {
		Patient patient = new Patient();
		patient.setEmail(email);
		patient.setFirstName(name);
		patient.setAuthProvider(provider);
		patRepo.save(patient);
	}

	public void updateNewCustomerAfterOAuthLoginSuccess(Patient patient, String name, AuthenticationProvider provider) {

		patient.setFirstName(name);
		patient.setAuthProvider(provider);

		patRepo.save(patient);
	}

}
