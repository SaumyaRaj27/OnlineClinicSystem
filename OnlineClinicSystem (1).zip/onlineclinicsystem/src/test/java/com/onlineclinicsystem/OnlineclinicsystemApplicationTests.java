package com.onlineclinicsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineclinicsystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
